from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm, LoginForm


def index(request):
    return render(request, 'admin/index.html')


def login_view(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.user.is_authenticated:
        return redirect('/account/adminpage')
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)

            if user is not None:
                login(request, user)
                if user.is_staff:  # Check if the user is admin (staff)
                    return redirect('adminpage')  # Redirect to admin dashboard
                else:
                    return redirect('adminpage')  # Redirect to user page or appropriate view
            else:
                msg = 'Invalid credentials'
        else:
            msg = 'Error validating form'

    return render(request, 'admin/login.html', {'form': form, 'msg': msg})

def logout_view(request):
    logout(request)  # Log the user out
    return redirect('/account/login/')

def register(request):
    msg = None
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            msg = 'user created'
            return redirect('login_view')
        else:
            msg = 'form is not valid'
    else:
        form = SignUpForm()
    return render(request,'admin/register.html', {'form': form, 'msg': msg})

@login_required
def admin(request):
    return render(request,'admin/dashboard.html')

def user(request):
    return render(request,'user.html')



# def admin(request):
#     return render(request,'admin.html')


# def user(request):
#     return render(request,'user.html')