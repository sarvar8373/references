from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('ad', views.index, name= 'index'),
    path('login/', views.login_view, name='login_view'),
    path('register/', views.register, name='register'),
    path('adminpage/', views.admin, name='adminpage'),
    path('account/logout/', views.logout_view, name='logout'),
    # path('adminpage/references', views.references, name='adminpage/references'),
    path('user/', views.user, name='user'),
    # path('adminpage/katalog', views.category_list, name='adminpage/katalog'),
]