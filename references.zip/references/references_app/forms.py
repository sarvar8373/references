from django import forms
from .models import TableHeader, TableRow, Category
from django.forms import modelformset_factory


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['category_name', 'category_decription']

class TableHeaderForm(forms.ModelForm):
    
    class Meta:
        model = TableHeader
        fields = ['header_name', 'references_category']
    header_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
        

class TableRowForm(forms.ModelForm):
    class Meta:
        model = TableRow
        fields = ['row_name', 'references_category', 'header']
    row_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))

class UploadFileForm(forms.Form):
    excel_file = forms.FileField()

TableHeaderFormSet = modelformset_factory(
    TableHeader, form=TableHeaderForm, extra=1, can_delete=True
)

TableRowFormSet = modelformset_factory(
    TableRow, form=TableRowForm, extra=1, can_delete=True
)
