from django.urls import path
# from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("", views.index, name="references_app"),
    path("references/", views.reflists, name="references"),
    path("soato/", views.soato, name="soato"),
    path("oked/", views.oked, name="oked"),
    path("okonx/", views.okonx, name="okonx"),
    path("opf/", views.opf, name="opf"),
    path("soogu/", views.soogu, name="soogu"),
    path("fs/", views.fs, name="fs"),
    path("doctype/", views.doctype, name="doctype"),
    path("country/", views.country, name="country"),
    path("nation/", views.nation, name="nation"),
    path('import/', views.import_classifier, name='import_classifier'),
    # path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('adminpage/references', views.references, name='adminpage/references'),
    path('categories/manage_table_headers/<int:category_id>/', views.manage_table_headers, name='manage_table_headers'),
    path('adminpage/settings', views.settings, name='settings'),
    path('adminpage/katalog', views.category_list, name='adminpage/katalog'),
    path('adminpage/create_category', views.create_category, name='create_category'),
    path(
        'categories/manage_table_rows/<int:category_id>/<int:header_id>/',
        views.manage_table_rows,
        name="manage_table_rows",
    ),
    path('references/<int:category_id>/', views.references_table, name='references_table'),
    # path('categories/create/', views.category_create, name='category_create'),
    # path('categories/<int:pk>/update/', views.category_update, name='category_update'),
    # path('categories/<int:pk>/delete/', views.category_delete, name='category_delete'),
    # path("login/", views.login, name="login"),
    # path("register/", views.register, name="register"),
]