from django.template import loader
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import Soato, OPF, OKONX, SOOGU, FS, DOCTYPE, COUNTRY, NATION
from django.core.paginator import Paginator
from django.shortcuts import render, get_object_or_404, redirect
from .models import TableHeader, TableRow, Category
from .forms import CategoryForm, TableHeaderForm, TableRowForm
from openpyxl import load_workbook
from django.contrib.auth.decorators import login_required
from django.forms import modelformset_factory
from django.http import JsonResponse

def index(request):
    template = loader.get_template('home.html')
    return HttpResponse(template.render())

def settings(request):
    template = loader.get_template('admin/settings.html')
    return HttpResponse(template.render())

def generic_list_view(request, model, template_name, extra_context=None):

    records_list = model.objects.all()
    code_filter = request.GET.get('code')
    name_uzl_filter = request.GET.get('name_uzl')
    name_ru_filter = request.GET.get('name_ru')
    
    
    
    if code_filter:
        records_list = records_list.filter(code__icontains=code_filter)
    if name_uzl_filter:
        records_list = records_list.filter(name_uzl__icontains=name_uzl_filter)
    if name_ru_filter:
        records_list = records_list.filter(name_ru__icontains=name_ru_filter)

    paginator = Paginator(records_list, 18)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    count = model.objects.count()

    context = {
        'page_obj': page_obj,
        'count': count,
    }
    if extra_context:
        context.update(extra_context)

    return render(request, template_name, context)

def soato(request):
    return generic_list_view(request, Soato, 'soato.html' )


def oked(request):
    return generic_list_view(request, OPF, 'oked.html')

def opf(request):
    return generic_list_view(request, OPF, 'opf.html')

def okonx(request):
    return generic_list_view(request, OKONX, 'okonx.html')

def soogu(request):
    return generic_list_view(request, SOOGU, 'soogu.html')

def fs(request):
    return generic_list_view(request, FS, 'fs.html')

def doctype(request):
    return generic_list_view(request, DOCTYPE, 'doctype.html')

def country(request):
    return generic_list_view(request, COUNTRY, 'country.html')

def nation(request):
    return generic_list_view(request, NATION, 'nation.html')

def reflists(request):
    references = [
        {'type': 'reference', 'title': 'soato', 'description': 'soato_text', 'link': 'soato', 'count': Soato.objects.count()},
        {'type': 'reference', 'title': 'oked', 'description': 'oked_text', 'link': 'oked', 'count': OPF.objects.count()},
        {'type': 'reference', 'title': 'okonx', 'description': 'okonx_text', 'link': 'okonx', 'count': OKONX.objects.count()},
        {'type': 'reference', 'title': 'opf', 'description': 'opf_text', 'link': 'opf', 'count': OPF.objects.count()},
        {'type': 'reference', 'title': 'fs', 'description': 'fs_text', 'link': 'fs', 'count': FS.objects.count()},
        {'type': 'reference', 'title': 'soogu', 'description': 'soogu_text', 'link': 'soogu', 'count': SOOGU.objects.count()},
        {'type': 'reference', 'title': 'doctype', 'description': 'doctype_text', 'link': 'doctype', 'count': DOCTYPE.objects.count()},
        {'type': 'reference', 'title': 'country', 'description': 'country_text', 'link': 'country', 'count': COUNTRY.objects.count()},
        {'type': 'reference', 'title': 'nation', 'description': 'nation_text', 'link': 'nation', 'count': NATION.objects.count()},
    ]
    
    categories = Category.objects.all()
    # Add categories to the list with a type field to differentiate them in the template
    categories_list = [{'type': 'category', 'id': category.id, 'category_name': category.category_name, 'category_decription': category.category_decription} for category in categories]
    
    combined_list = references + categories_list  # Combine references and categories
    
    paginator = Paginator(combined_list, 3)  # Show 3 items per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'pages/references.html', {'page_obj': page_obj})


def import_classifier(request):
    if request.method == 'POST' and request.FILES.get('file'):
        excel_file = request.FILES['file']
        
        try:
            workbook = load_workbook(excel_file)
            sheet = workbook.active
            for row in sheet.iter_rows(min_row=2, values_only=True):  # Skip header row
                if any(row): 
                    try:
                        id, version, code, s_comment, s_create, s_status, name_ru, name_uz, name_uzl, name_short_ru, name_short_uz, name_short_uzl, s_user_id  = row
                        
                        # Debug: print data to inspect
                        # Convert fields to appropriate types where necessary
                        version = int(version) if version is not None else 0
                        s_user_id = int(s_user_id) if s_user_id is not None else None
                        
                        # Create a new SOOGU object and save it
                        COUNTRY.objects.create(
                            id=int(id),
                            version=version,
                            code=code,
                            s_comment=s_comment,
                            s_create=s_create,
                            s_status=s_status,
                            name_ru=name_ru,
                            name_uz=name_uz,
                            name_uzl=name_uzl,
                            name_short_ru=name_short_ru,
                            name_short_uz=name_short_uz,
                            name_short_uzl=name_short_uzl,
                            s_user_id=s_user_id,
                            
                        )

                    except Exception as e:
                        # Log any error in case of data mismatch or missing values
                        print(f"Error importing row: {row} - {e}")
                        continue

        except Exception as e:
            # Log any critical errors related to file processing
            return HttpResponse(f"Failed to process file: {e}")

        return HttpResponse("File uploaded and data imported successfully!")

    return render(request, 'import_classifier.html')

@login_required
def references(request):
    records_list = DOCTYPE.objects.all()
    name_uzl_filter = request.GET.get('name_uzl')

    if name_uzl_filter:
        records_list = records_list.filter(name_uzl__icontains=name_uzl_filter)

    paginator = Paginator(records_list, 18)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request,'admin/references.html', {'page_obj': page_obj})

@login_required
def category_list(request):
    categories = Category.objects.all()
    form = CategoryForm()

    # Handle form submission to add a new category
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminpage/katalog')

    # Handle category deletion
    if request.method == 'POST' and 'delete-category' in request.POST:
        category_id = request.POST.get('category_id')
        category = get_object_or_404(Category, id=category_id)
        category.delete()
        return redirect('adminpage/katalog')

    context = {
        'categories': categories,
        'form': form,
    }
    return render(request, 'admin/category_list.html', context)

@login_required
def category_update(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'category_form.html', {'form': form})

def create_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()  # Save the new category to the database
            return redirect('katalog')  # Redirect to a category list view or another page
    else:
        form = CategoryForm()
    
    return render(request, 'admin/create_category.html', {'form': form})

@login_required
def manage_table_headers(request, category_id):
    category = get_object_or_404(Category, id=category_id)

    # Handle DELETE requests for deleting a specific TableHeader
    if request.method == "DELETE" and "header_id" in request.GET:
        header_id = request.GET.get("header_id")
        try:
            table_header = TableHeader.objects.get(pk=header_id, references_category=category)
            table_header.delete()
            return JsonResponse({"success": True, "message": "Table header deleted successfully."})
        except TableHeader.DoesNotExist:
            return JsonResponse({"success": False, "message": "Table header not found."}, status=404)

    # Create the formset
    TableHeaderFormSet = modelformset_factory(
        TableHeader,
        form=TableHeaderForm,
        extra=1,
        can_delete=True,
    )

    table_headers = TableHeader.objects.filter(references_category=category_id)

    if request.method == "POST":
        formset = TableHeaderFormSet(request.POST, queryset=table_headers)

        if formset.is_valid():
            instances = formset.save(commit=False)  # Do not commit to allow additional processing
            for instance in instances:
                if not instance.pk:
                    instance.category = category  # Assign category to new rows
                instance.references_category = category
                instance.save()

            # Handle deletions manually
            for form in formset.forms:
                if form.cleaned_data.get("DELETE"):
                    if form.instance.pk:  # Ensure the object exists in the database
                        print(f"Deleting: {form.instance}")  # Debug log
                        form.instance.delete()

            # Save formset changes to the database
            formset.save()

            # Redirect to the same page to refresh the view
            return redirect("manage_table_headers", category_id=category.id)
        else:
            print(formset.errors)  # Debugging: log formset errors
    else:
        formset = TableHeaderFormSet(queryset=table_headers)

    return render(
        request,
        "admin/manage_table_headers.html",
        {"formset": formset, "category": category},
    )
@login_required
def manage_table_rows(request, category_id, header_id):
    # Get the header and associated category
    header = get_object_or_404(TableHeader, id=header_id)
    category = get_object_or_404(Category, id=category_id)

    # Query rows linked to the header and category
    table_rows = TableRow.objects.filter(references_category=category_id, header=header )

    # Create a formset for managing rows
    TableRowFormSet = modelformset_factory(
        TableRow,
        form=TableRowForm,
        extra=1,  # Display an additional empty form for new rows
        can_delete=True,  # Allow deletion of rows
    )

    # Handle DELETE request for deleting a row
    if request.method == "DELETE" and "row_id" in request.GET:
        row_id = request.GET.get("row_id")
        try:
            table_row = TableRow.objects.get(pk=row_id, references_category=category, header=header)
            table_row.delete()
            return JsonResponse({"success": True, "message": "Table row deleted successfully."})
        except TableRow.DoesNotExist:
            return JsonResponse({"success": False, "message": "Table row not found."}, status=404)

    if request.method == "POST":
        formset = TableRowFormSet(request.POST, queryset=table_rows)
        if formset.is_valid():
            # Save valid instances and assign the header and category
            instances = formset.save(commit=False)
            for instance in instances:
                if not instance.pk:  # Only assign if it's a new instance
                    instance.category = category  # Assign the current category instance, not the ID
                instance.header = header
                instance.references_category = category# Assign the current header
                instance.save()

            # Handle deletions manually
            for form in formset.forms:
                if form.cleaned_data.get("DELETE"):
                    if form.instance.pk:  # Ensure the object exists in the database
                        print(f"Deleting: {form.instance}")  # Debug log
                        form.instance.delete()
                        
            formset.save()
            return redirect("manage_table_rows", category_id=category.id, header_id=header_id)
        else:
            # Print errors for debugging
            print(formset.errors)
    else:
        # Create an unbound formset for GET requests
        formset = TableRowFormSet(queryset=table_rows)

    # Render the management template with the formset and associated data
    return render(
        request,
        "admin/manage_table_rows.html",  # Adjust the template path as needed
        {
            "formset": formset,
            "header": header,
            "category_id": category.id,
        },
    )
def references_table(request, category_id):
    category = get_object_or_404(Category, id=category_id)
   
    headers = TableHeader.objects.filter(references_category=category)
    rows = TableRow.objects.filter(references_category=category)

    table_data = []
    for header in headers:
        table_data.append({
            'header': header,
            'rows': rows.filter(header=header),  
        })

    rows_grouped = []
    max_row_count = max(len(item['rows']) for item in table_data) if table_data else 0

    for i in range(max_row_count):
        row = []
        for item in table_data:
            row.append(item['rows'][i] if i < len(item['rows']) else '')
        rows_grouped.append(row)

    paginator = Paginator(rows_grouped, 15)  
    page_number = request.GET.get('page')  
    page_obj = paginator.get_page(page_number)  

    context = {
        'category': category,
        'table_data': table_data,
        'rows_grouped': page_obj,  # Pass the paginated rows
        'paginator': paginator,   # Pass the paginator
    }
    return render(request, 'pages/references_table.html', context)

    
# def login(request):
#     template = loader.get_template('admin/login.html')
#     return HttpResponse(template.render())

# def register(request):
#     template = loader.get_template('admin/register.html')
#     return HttpResponse(template.render())